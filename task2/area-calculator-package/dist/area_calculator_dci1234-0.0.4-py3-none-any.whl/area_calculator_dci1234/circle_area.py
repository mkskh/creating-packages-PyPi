from math import pi


def circle_area(radius):
    return round((pi * (radius ** 2)), 2)