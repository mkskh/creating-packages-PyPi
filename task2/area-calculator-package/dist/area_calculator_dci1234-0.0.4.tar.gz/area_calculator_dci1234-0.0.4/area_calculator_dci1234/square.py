def square(a):
    return a * a