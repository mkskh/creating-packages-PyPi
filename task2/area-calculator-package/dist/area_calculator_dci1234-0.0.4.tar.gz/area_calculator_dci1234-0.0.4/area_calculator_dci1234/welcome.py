def welcome():
    print('Hello, welcome to area calculator package!')